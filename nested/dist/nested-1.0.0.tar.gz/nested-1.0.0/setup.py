from distutils.core import setup

setup (
	name			= 'nested',
	version			= '1.0.0',
	py_modules		= ['nested'],
	author			= 'Emidio ALves',
	author_email	= 'emidio_alves@hotmail.com',
	url				= 'www.farmaciaescola.ufc.br',
	description		= 'A simple printer of nested list',
)